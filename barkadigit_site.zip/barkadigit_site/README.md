
# Barka Digit – Vitrine pro (DigiHub)

**Identité**
- Slogan : Le digital au service de l’Afrique
- WhatsApp : https://wa.me/22798174737
- Email : contactbarkadigit@gmail.com
- Facebook : https://www.facebook.com/share/1JBq9FrcDF/
- Adresse : Bobiel, Station Sahara, voie vers CEG35, Niamey, Niger

## Structure
- `index.html` (accueil, hero CTA WhatsApp)
- `a-propos.html`
- `services/index.html` + `services/*.html` (6 pages dédiées)
- `contact.html` (formulaire + coordonnées)
- `assets/css/styles.css`, `assets/js/app.js`, `assets/js/barkabot.js`
- `faq.json` (connaissances BarkaBot)
- SEO : `sitemap.xml`, `robots.txt`, OpenGraph
- PWA : `manifest.json`, `sw.js`
- Icônes : `assets/icons/*`, favicon

## Édition rapide
- Numéro WhatsApp : modifiez la constante `WHATSAPP` dans les fichiers HTML/JS (recherche globale).
- Email : remplacez `contactbarkadigit@gmail.com`.
- Slogan : section hero (`index.html`).

## Déploiement DigiHub (exemple CLI)
> Remplacez `DIGIHUB_TOKEN` et le nom du projet.  
> Si DigiHub fournit une CLI, un script pourrait ressembler à :

```bash
export DIGIHUB_TOKEN=xxxx
digihub projects create barkadigit --region=eu
digihub deploy --project barkadigit --dir . --ssl --yes
# URL attendue (exemple) :
# https://barkadigit.digihub.app
```

### Backend e‑mail (serverless suggéré)
Créez une fonction `/api/send` côté DigiHub qui envoie l’email à `contactbarkadigit@gmail.com` (ex : Node.js + nodemailer ou service externe comme Mailgun/Resend).  
Réponse `200` attendue par `contact.html`.

### Google Analytics 4
Définissez `window.GA_ID = 'G-XXXX'` dans l’entête des pages pour activer GA4.

### BarkaBot – mise à jour du FAQ
Modifiez `faq.json` puis reconstruisez/déployez. BarkaBot est volontairement limité au périmètre du site.

## SEO
- `sitemap.xml` pointe vers `https://barkadigit.digihub.app` (mettez l’URL finale).
- `robots.txt` inclut le sitemap.

## Dev local
Ouvrez `index.html` dans un navigateur. Pour PWA/service-worker, servez en local (ex : `python -m http.server 8000`).

