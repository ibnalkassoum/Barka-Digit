
// BarkaBot - simple on-page FAQ/chat
(function(){ 
  const state = { open:false, data:null };
  async function loadFAQ(){
    if(state.data) return state.data;
    const res = await fetch('/faq.json').catch(()=>fetch('faq.json'));
    state.data = await res.json();
    return state.data;
  }
  function createUI(){
    const btn = document.createElement('button');
    btn.setAttribute('aria-label','Ouvrir BarkaBot');
    btn.style.cssText = 'position:fixed;right:18px;bottom:18px;border:none;border-radius:50%;width:56px;height:56px;background:#FF8C00;color:#111;font-weight:800;box-shadow:0 8px 24px rgba(0,0,0,.18);cursor:pointer;z-index:60';
    btn.textContent = '💬';
    document.body.appendChild(btn);
    const box = document.createElement('div');
    box.style.cssText='position:fixed;right:18px;bottom:84px;width:320px;max-height:60vh;background:#fff;border:1px solid #e0e6f4;border-radius:14px;box-shadow:0 12px 40px rgba(10,42,102,.15);display:none;flex-direction:column;overflow:hidden;z-index:60';
    box.innerHTML = `
      <div style="background:#0A2A66;color:#fff;padding:10px 12px;font-weight:700">BarkaBot</div>
      <div id="bb-stream" style="padding:12px;gap:8px;display:flex;flex-direction:column;overflow:auto"></div>
      <form id="bb-form" style="display:flex;gap:6px;padding:10px;border-top:1px solid #eef3ff">
        <input id="bb-input" required placeholder="Posez une question (services, contact…)" style="flex:1;border:1px solid #e0e6f4;border-radius:10px;padding:10px"/>
        <button class="btn" style="border:none;border-radius:10px;background:#FF8C00">Envoyer</button>
      </form>`;
    document.body.appendChild(box);
    btn.addEventListener('click',()=>{ state.open=!state.open; box.style.display= state.open?'flex':'none'; });
    return {box};
  }
  function respond(stream, text, faq){
    // Very small rule-based responder limited to site scope
    const t = text.toLowerCase();
    function push(role,msg,cta=null){
      const bubble = document.createElement('div');
      bubble.style.cssText='padding:10px 12px;border-radius:10px;max-width:90%';
      if(role==='user'){ bubble.style.alignSelf='flex-end'; bubble.style.background='#eef3ff'; }
      else { bubble.style.background='#fff7ec'; }
      bubble.innerHTML = msg + (cta?` <a href="${cta.href}" target="_blank" rel="noopener" class="btn" style="padding:6px 10px;margin-left:6px">${cta.label}</a>`:'');
      stream.appendChild(bubble); stream.scrollTop=stream.scrollHeight;
    }
    push('user', text);
    if(/whatsapp|contacter|contact|parler|discuter/.test(t)){ 
      push('bot', 'Vous pouvez nous écrire directement sur WhatsApp.', {href:'https://wa.me/22798174737', label:'Ouvrir WhatsApp'}); return; 
    }
    if(/adresse|où|localisation/.test(t)){ 
      push('bot', 'Notre adresse : Bobiel, Station Sahara, voie vers CEG35, Niamey, Niger.', null); return; 
    }
    if(/email|mail/.test(t)){ push('bot', 'E-mail : contactbarkadigit@gmail.com', null); return; }
    const svc = Object.keys(faq.services).find(k => t.includes(k.replace('-', ' ')) || t.includes(k));
    if(/service|offrez|proposez/.test(t) || svc){ 
      if(svc) push('bot', `Service “${svc}” : ${faq.services[svc]}`, {href:'/services/'+svc+'.html',label:'Découvrir'});
      else push('bot', 'Nous proposons : e‑commerce, publicité digitale, création vidéo, formations, placement de marketeurs, produits numériques.', {href:'/services',label:'Voir tous les services'});
      return;
    }
    // default short answer
    push('bot', 'Je réponds aux questions Barka Digit (services, contact, adresse).', {href:'https://wa.me/22798174737',label:'WhatsApp'});
  }
  document.addEventListener('DOMContentLoaded', async()=>{
    const faq = await loadFAQ();
    const {box} = createUI();
    const stream = box.querySelector('#bb-stream');
    stream.innerHTML = `<div style="opacity:.9">Salut 👋 Je suis <b>BarkaBot</b>. Posez vos questions sur Barka Digit.</div>`;
    const form = box.querySelector('#bb-form');
    form.addEventListener('submit',(e)=>{ e.preventDefault(); const val = box.querySelector('#bb-input').value.trim(); if(!val) return; box.querySelector('#bb-input').value=''; respond(stream,val,faq); });
  });
})();
