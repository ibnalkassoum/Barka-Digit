
// Smooth anchor scroll for internal links
document.addEventListener('click', (e) => {
  const a = e.target.closest('a[href^="#"]');
  if (!a) return;
  const el = document.querySelector(a.getAttribute('href'));
  if (el) { e.preventDefault(); el.scrollIntoView({behavior:'smooth'}); }
});

// Reveal on scroll
const io = new IntersectionObserver(entries=>{
  entries.forEach(en=>{ if(en.isIntersecting) en.target.style.animation='fadeIn .6s ease both'; });
}, {threshold:.12});
document.querySelectorAll('.card, section').forEach(el=>io.observe(el));

// WhatsApp helper
function openWhatsApp(message='Bonjour, je souhaite discuter de mon projet.'){
  const url = 'https://wa.me/22798174737?text='+encodeURIComponent(message);
  window.open(url, '_blank', 'noopener');
}

// GA4 placeholder (set window.GA_ID in config.js if needed)
if (window.GA_ID) {
  let gtagScript = document.createElement('script');
  gtagScript.async = true;
  gtagScript.src = `https://www.googletagmanager.com/gtag/js?id=${window.GA_ID}`;
  document.head.appendChild(gtagScript);
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  window.gtag = gtag;
  gtag('js', new Date());
  gtag('config', window.GA_ID);
}
